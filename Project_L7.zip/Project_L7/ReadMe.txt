Ionescu Rares-Andrei
Leonte Robert
Petre George-Alexandru