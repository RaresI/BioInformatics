Ionescu Rares-Andrei
Petre George-Alexandru
Leonte Robert-Cristian