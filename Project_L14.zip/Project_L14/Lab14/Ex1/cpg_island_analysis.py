import math
from collections import defaultdict

def count_transitions(sequence):
    transitions_from = defaultdict(lambda: defaultdict(int))
    base_counts = defaultdict(int)
    
    for i in range(len(sequence) - 1):
        current = sequence[i]
        next_base = sequence[i + 1]
        transitions_from[current][next_base] += 1
        base_counts[current] += 1
    
    transition_probs = {}
    transitions = {}
    
    for base1 in ['A', 'C', 'G', 'T']:
        total = base_counts[base1] if base_counts[base1] > 0 else 1
        for base2 in ['A', 'C', 'G', 'T']:
            transition = base1 + base2
            count = transitions_from[base1][base2]
            transitions[transition] = count
            prob = count / total if total > 0 else 0
            transition_probs[transition] = prob
    
    return transitions, transition_probs

def calculate_log_likelihood(probs_plus, probs_minus):
    log_likelihood = {}
    
    for base1 in ['A', 'C', 'G', 'T']:
        for base2 in ['A', 'C', 'G', 'T']:
            transition = base1 + base2
            p_plus = probs_plus.get(transition, 1e-10)
            p_minus = probs_minus.get(transition, 1e-10)
            
            if p_plus > 0 and p_minus > 0:
                log_likelihood[transition] = math.log2(p_plus / p_minus)
            else:
                log_likelihood[transition] = 0
    
    return log_likelihood

def analyze_sequence(sequence, log_likelihood):
    total_score = 0
    
    for i in range(len(sequence) - 1):
        transition = sequence[i] + sequence[i + 1]
        score = log_likelihood.get(transition, 0)
        total_score += score
    
    return total_score

S1 = "ATCGATTCGATATCATACACGTAT"
S2 = "CTCGACTAGTATGAAGTCCACGCTTG"
S_test = "CAGGTTGGAAACGTAA"

print("CpG Island Analysis - Lab 14")
print("-" * 50)

print("\nStep 1: CpG+ Model (Island)")
print("Sequence S1:", S1)
transitions_plus, probs_plus = count_transitions(S1)
print("\nTransition probabilities:")
print("From\\To    A       C       G       T")
for base1 in ['A', 'C', 'G', 'T']:
    row = f"{base1}        "
    for base2 in ['A', 'C', 'G', 'T']:
        prob = probs_plus.get(base1 + base2, 0)
        row += f"{prob:.3f}   "
    print(row)

print("\n\nStep 2: CpG- Model (Non-Island)")
print("Sequence S2:", S2)
transitions_minus, probs_minus = count_transitions(S2)
print("\nTransition probabilities:")
print("From\\To    A       C       G       T")
for base1 in ['A', 'C', 'G', 'T']:
    row = f"{base1}        "
    for base2 in ['A', 'C', 'G', 'T']:
        prob = probs_minus.get(base1 + base2, 0)
        row += f"{prob:.3f}   "
    print(row)

print("\n\nStep 3: Log-Likelihood Matrix")
log_likelihood = calculate_log_likelihood(probs_plus, probs_minus)
print("\nTransition  log2(P+/P-)")
print("-" * 30)
for base1 in ['A', 'C', 'G', 'T']:
    for base2 in ['A', 'C', 'G', 'T']:
        transition = base1 + base2
        score = log_likelihood.get(transition, 0)
        print(f"{transition}          {score:.3f}")

print("\n\nStep 4: Test Sequence Analysis")
print("Sequence:", S_test)
total_score = analyze_sequence(S_test, log_likelihood)

print(f"\nTotal score: {total_score:.3f}")
print("-" * 50)

if total_score > 0:
    print("Result: Sequence belongs to CpG island")
else:
    print("Result: Sequence does NOT belong to CpG island")
