import math
from collections import defaultdict
import re

def preprocess_text(text):
    text = text.lower()
    text = re.sub(r'[^\w\s]', '', text)
    words = text.split()
    return words

def count_word_transitions(words):
    transitions_from = defaultdict(lambda: defaultdict(int))
    word_counts = defaultdict(int)
    
    for i in range(len(words) - 1):
        current = words[i]
        next_word = words[i + 1]
        transitions_from[current][next_word] += 1
        word_counts[current] += 1
    
    transition_probs = {}
    
    for word1 in transitions_from.keys():
        total = word_counts[word1]
        for word2 in transitions_from[word1].keys():
            transition = (word1, word2)
            count = transitions_from[word1][word2]
            prob = count / total if total > 0 else 0
            transition_probs[transition] = prob
    
    return transition_probs

def calculate_log_likelihood(probs_eminescu, probs_stanescu):
    all_transitions = set(probs_eminescu.keys()) | set(probs_stanescu.keys())
    log_likelihood = {}
    
    for transition in all_transitions:
        p_eminescu = probs_eminescu.get(transition, 1e-10)
        p_stanescu = probs_stanescu.get(transition, 1e-10)
        
        if p_eminescu > 0 and p_stanescu > 0:
            log_likelihood[transition] = math.log2(p_eminescu / p_stanescu)
        else:
            log_likelihood[transition] = 0
    
    return log_likelihood

def segment_text(words, log_likelihood, window_size=8):
    segments = []
    current_segment = {
        'words': [],
        'author': None,
        'avg_score': 0
    }
    
    for i in range(len(words)):
        if i < window_size - 1:
            current_segment['words'].append(words[i])
            continue
        
        window_start = max(0, i - window_size + 1)
        window = words[window_start:i + 1]
        score = 0
        
        for j in range(len(window) - 1):
            transition = (window[j], window[j + 1])
            score += log_likelihood.get(transition, 0)
        
        avg_score = score / (window_size - 1) if window_size > 1 else score
        
        if avg_score > 0.5:
            author = "Eminescu"
        elif avg_score < -0.5:
            author = "Stanescu"
        else:
            author = "Neither"
        
        if current_segment['author'] == author or current_segment['author'] is None:
            current_segment['words'].append(words[i])
            current_segment['author'] = author
            current_segment['avg_score'] = avg_score
        else:
            segments.append(current_segment)
            current_segment = {
                'words': [words[i]],
                'author': author,
                'avg_score': avg_score
            }
    
    if current_segment['words']:
        segments.append(current_segment)
    
    return segments

eminescu_text = """
sara pe deal cu brau de aburi leans
si soarele din urma ei se trage
coboara noaptea umbra de clestar
pe crestele din munte se coboara
luceafarul ce rasare deasupra marii
si arde mandra stea tot mai aproape
vai cui imi pare rau ca nu mai sunt cu tine
de ce mi ai luat inima si nu mi o mai dai
prin codri murmurand si prin campii
venind de la rasarit pana la apus
cu frunza si cu floarea si cu dorul ganganii
te uiti la mine drag cum ma privesti mereu
si luna pe cerul senin rasare trandafirie
pe campii de argint si flori frumoase
privesc la tine drag si ma gandesc la tine
ca esti mai scumpa decat toate florile campului
"""

stanescu_text = """
necuvintele sunt cuvinte care nu se mai rostesc
ele plutesc in aer ca niste frunze moarte
si cad in inima ta ca ploaia toamna
cand totul e pierdut si nimic nu mai conteaza
eu sunt un vers si tu esti o strofa
impreuna facem o poezie nesfarsita
cuvintele noastre se impletesc ca fire de iarba
si cresc spre cer ca niste copaci batrani
visele mele sunt umbre ale gandurilor tale
si gandurile tale sunt ecouri ale viselor mele
suntem doi straina unul pentru celalalt
dar totusi impreuna ca noaptea si ziua
cand imi spui cuvinte dulci imi amintesc de tine
si inima mea bate mai tare ca niciodata
sunt un om simplu cu vise complicate
si tu esti o stea ce straluceste pe cer
"""

mihai_text = """
sara pe deal cu brau de aburi leans
necuvintele sunt cuvinte care nu se mai rostesc
si luna pe cerul senin rasare trandafirie
visele mele sunt umbre ale gandurilor tale
luceafarul ce rasare deasupra marii
cand totul e pierdut si nimic nu mai conteaza
privesc la tine drag si ma gandesc la tine
eu sunt un vers si tu esti o strofa
cu frunza si cu floarea si cu dorul ganganii
cuvintele noastre se impletesc ca fire de iarba
de ce mi ai luat inima si nu mi o mai dai
sunt un om simplu cu vise complicate
pe campii de argint si flori frumoase
si tu esti o stea ce straluceste pe cer
coboara noaptea umbra de clestar
ele plutesc in aer ca niste frunze moarte
"""

print("Plagiarism Analysis - Lab 14")
print("-" * 50)

eminescu_words = preprocess_text(eminescu_text)
probs_eminescu = count_word_transitions(eminescu_words)

stanescu_words = preprocess_text(stanescu_text)
probs_stanescu = count_word_transitions(stanescu_words)

log_likelihood = calculate_log_likelihood(probs_eminescu, probs_stanescu)

mihai_words = preprocess_text(mihai_text)
segments = segment_text(mihai_words, log_likelihood, window_size=8)

print("\nAnalyzing Mihai's text...\n")

for i, segment in enumerate(segments):
    text = ' '.join(segment['words'])
    author = segment['author']
    
    if author == "Eminescu":
        print(f"[Eminescu] {text}")
    elif author == "Stanescu":
        print(f"[Stanescu] {text}")
    else:
        print(f"[?] {text}")

print("\n" + "-" * 50)

eminescu_count = sum(1 for s in segments if s['author'] == 'Eminescu')
stanescu_count = sum(1 for s in segments if s['author'] == 'Stanescu')
neither_count = sum(1 for s in segments if s['author'] == 'Neither')

total = len(segments)
print(f"\nResults:")
print(f"Eminescu: {eminescu_count} segments ({eminescu_count/total*100:.0f}%)")
print(f"Stanescu: {stanescu_count} segments ({stanescu_count/total*100:.0f}%)")
print(f"Uncertain: {neither_count} segments ({neither_count/total*100:.0f}%)")

print(f"\nConclusion: Text contains parts from both authors - plagiarism detected!")
