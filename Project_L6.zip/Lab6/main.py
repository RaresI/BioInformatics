from Bio import SeqIO
import random
import matplotlib.pyplot as plt
import numpy as np

file_path = "gene.fna"
record = next(SeqIO.parse(file_path, "fasta"))
dna_sequence = str(record.seq)

sequence_length = len(dna_sequence)
print(f"DNA length: {sequence_length} bases")

if not (1000 <= sequence_length <= 3000):
    raise ValueError("DNA sequence must be between 1000 and 3000 bases long.")

num_samples = 10
samples = []

for _ in range(num_samples):
    sample_length = random.randint(100, sequence_length)
    start = random.randint(0, len(dna_sequence) - sample_length)
    fragment = dna_sequence[start:start + sample_length]
    samples.append(fragment)

fragment_lengths = [len(f) for f in samples]
print("Fragment lengths (bp):", fragment_lengths)

migration_distances = 1 / np.sqrt(np.array(fragment_lengths))
migration_distances = (migration_distances - migration_distances.min()) / \
                      (migration_distances.max() - migration_distances.min())

fig, ax = plt.subplots(figsize=(3, 6))
ax.set_facecolor("black")

sorted_data = sorted(zip(migration_distances, fragment_lengths), key=lambda x: x[0])

min_label_gap = 0.05
last_y = -1

for d, bp in sorted_data:
    ax.hlines(d, 0.2, 0.8, colors="white", linewidth=3)

    if d - last_y < min_label_gap:
        d = last_y + min_label_gap
    ax.text(0.85, d, f"{bp} bp", color="white", va="center", fontsize=8)
    last_y = d

for bp in [3000, 1500, 500]:
    y = (1/np.sqrt(bp) - 1/np.sqrt(max(fragment_lengths))) / \
        (1/np.sqrt(min(fragment_lengths)) - 1/np.sqrt(max(fragment_lengths)))
    ax.text(0.05, y, f"{bp} bp", color="white", va="center", fontsize=8)

ax.set_xlim(0, 1)
ax.set_ylim(0, 1)
ax.axis("off")
plt.title("Simulated Gel Electrophoresis", color="white")

output_file = "gel_simulation.png"
plt.savefig(output_file, dpi=300, bbox_inches='tight', facecolor='black')
plt.close()

print(f"Gel electrophoresis image saved as '{output_file}'")
