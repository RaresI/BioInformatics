# ==========================================
# In-silico EcoRI digest & gel visualization
# ==========================================
# - Reads a multi-FASTA file with influenza genomes
# - Digests each with EcoRI (GAATTC; cut G^AATTC)
# - Simulates electrophoresis gels (combined & per-genome)
# - Compares fragment counts and highlights the most segmented genomes
#
# Usage:
#   python digest_gel_influenza.py
#
# Configure the input/output just below.
# ==========================================

from Bio import SeqIO
import numpy as np
import matplotlib.pyplot as plt
import re
from pathlib import Path
from collections import defaultdict

# -------------------------------
# Configuration
# -------------------------------
FASTA_PATH = "sequences (2).fasta"   # your multi-FASTA file
OUT_DIR = Path("gel_outputs")         # where figures will be saved
LANE_WIDTH = 0.7                      # visual width of each lane (0..1)
BAND_THICKNESS = 3                    # line width of bands in plots
DPI = 300

# -------------------------------
# EcoRI recognition & cut model
# -------------------------------
ENZYME_NAME = "EcoRI"                # aka "ECOR1"
MOTIF = "GAATTC"
CUT_OFFSET = 1                       # cut between G^AATTC (after the G)

def ecoRI_digest_fragment_sizes(seq: str) -> list[int]:
    """Return fragment sizes (bp) after digesting a linear sequence with EcoRI."""
    seq = str(seq).upper()
    cut_positions = []
    for m in re.finditer(MOTIF, seq):
        cut_positions.append(m.start() + CUT_OFFSET)

    if not cut_positions:
        return [len(seq)]

    cut_positions = sorted(cut_positions)
    sizes = []
    prev = 0
    for c in cut_positions:
        sizes.append(c - prev)
        prev = c
    sizes.append(len(seq) - prev)
    return sizes

# -------------------------------
# Migration model for gel
# -------------------------------
def migration_positions_bp(sizes_bp, global_min_bp=None, global_max_bp=None):
    sizes = np.array(sizes_bp, dtype=float)
    sizes[sizes < 1] = 1.0
    log_sizes = np.log10(sizes)

    if global_min_bp is None or global_max_bp is None:
        lo, hi = log_sizes.min(), log_sizes.max()
    else:
        lo = np.log10(max(1.0, global_min_bp))
        hi = np.log10(max(1.0, global_max_bp))

    eps = 1e-9
    norm = (log_sizes - lo) / max(hi - lo, eps)
    y = 1.0 - norm
    return np.clip(y, 0.0, 1.0)

def non_overlapping_labels(ys, min_gap=0.02):
    ys_sorted = np.array(sorted(ys))
    adjusted = []
    last = -1.0
    for y in ys_sorted:
        if last < 0:
            adjusted.append(y)
            last = y
        else:
            if y - last < min_gap:
                y = last + min_gap
            adjusted.append(min(y, 1.0))
            last = y
    order = np.argsort(ys)
    out = np.empty_like(ys, dtype=float)
    out[order] = adjusted
    return out

# -------------------------------
# Plotting helpers
# -------------------------------
def draw_lane(ax, y_positions, label=None, x_center=0.5):
    x0 = x_center - LANE_WIDTH/2
    x1 = x_center + LANE_WIDTH/2
    for y in y_positions:
        ax.hlines(y, x0, x1, colors="white", linewidth=BAND_THICKNESS)
    if label:
        ax.text(x_center, 1.03, label, color="white", ha="center", va="bottom", fontsize=8)

def style_gel_axes(ax, title=None):
    ax.set_facecolor("black")
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.axis("off")
    if title:
        ax.set_title(title, color="white", pad=12)

# -------------------------------
# Read sequences & digest
# -------------------------------
OUT_DIR.mkdir(parents=True, exist_ok=True)
records = list(SeqIO.parse(FASTA_PATH, "fasta"))
if len(records) == 0:
    raise RuntimeError("No sequences found in the FASTA file.")

digest_sizes = {}
all_sizes = []

for rec in records:
    sizes = ecoRI_digest_fragment_sizes(str(rec.seq))
    digest_sizes[rec.id] = sizes
    all_sizes.extend(sizes)

# -------------------------------
# Identify genome(s) with most fragments
# -------------------------------
fragment_counts = {rid: len(sizes) for rid, sizes in digest_sizes.items()}
max_count = max(fragment_counts.values())
most_segmented = [rid for rid, c in fragment_counts.items() if c == max_count]

print(f"Restriction enzyme: {ENZYME_NAME} (motif {MOTIF}, cut G^AATTC)")
print("Fragments per genome:")
for rid in sorted(fragment_counts):
    print(f"  {rid}: {fragment_counts[rid]} fragments")

print(f"\nGenome(s) with the most DNA segments ({max_count}):")
for rid in most_segmented:
    print(f"  - {rid}")

# -------------------------------
# Combined multi-lane gel (shared scale) — FIXED VERSION
# -------------------------------
global_min_bp = min(all_sizes)
global_max_bp = max(all_sizes)

n = len(records)
fig_w = max(8.0, 1.2 * n)  # wider figure for many lanes
fig, ax = plt.subplots(figsize=(fig_w, 6))
style_gel_axes(ax, title=f"{ENZYME_NAME} digest: Combined Gel (all genomes)")

# Evenly spaced lane centers across the width
x_centers = np.linspace(0.05, 0.95, n)

# Draw each genome lane
for rec, xc in zip(records, x_centers):
    sizes = digest_sizes[rec.id]
    ys = migration_positions_bp(sizes, global_min_bp, global_max_bp)
    draw_lane(ax, ys, x_center=xc)

# Rotated and shortened genome labels below each lane
for rec, xc in zip(records, x_centers):
    short_id = rec.id.split('.')[0]
    ax.text(xc, -0.05, short_id, color="white",
            ha="right", va="top", rotation=45, fontsize=7)

ax.set_xlim(0, 1)
ax.set_ylim(-0.1, 1)
ax.axis("off")

combined_path = OUT_DIR / "combined_gel_ecori.png"
plt.savefig(combined_path, dpi=DPI, bbox_inches="tight", facecolor="black")
plt.close()

# -------------------------------
# Separate gels per genome (own scaling; avoids overlap)
# -------------------------------
for rec in records:
    sizes = digest_sizes[rec.id]
    ys = migration_positions_bp(sizes)
    ys_label = non_overlapping_labels(ys, min_gap=0.03)

    fig, ax = plt.subplots(figsize=(3.2, 6))
    style_gel_axes(ax, title=f"{rec.id} — EcoRI digest")

    draw_lane(ax, ys, x_center=0.5)
    for y, bp in zip(ys_label, [int(s) for s in sizes]):
        ax.text(0.86, y, f"{bp} bp", color="white", va="center", fontsize=8)

    out_path = OUT_DIR / f"{rec.id}_gel_ecori.png"
    plt.savefig(out_path, dpi=DPI, bbox_inches="tight", facecolor="black")
    plt.close()

# -------------------------------
# Bar chart: fragment counts per genome
# -------------------------------
ids = list(fragment_counts.keys())
vals = [fragment_counts[i] for i in ids]
highlight = set(most_segmented)

fig, ax = plt.subplots(figsize=(max(6, 0.6 * len(ids)), 4))
bars = ax.bar(ids, vals)
for b, rid in zip(bars, ids):
    if rid in highlight:
        b.set_alpha(1.0)
        b.set_hatch("//")
    else:
        b.set_alpha(0.8)

ax.set_ylabel("Number of fragments (EcoRI)")
ax.set_title("Fragment count per genome (EcoRI digest)")
ax.set_xticklabels(ids, rotation=45, ha="right")
ax.grid(axis="y", linestyle=":", alpha=0.5)
plt.tight_layout()
bar_path = OUT_DIR / "fragment_counts_ecori.png"
plt.savefig(bar_path, dpi=DPI)
plt.close()

print("\nSaved figures:")
print(f"  - Combined gel: {combined_path}")
print(f"  - Per-genome gels: {OUT_DIR}/<id>_gel_ecori.png")
print(f"  - Fragment count bar chart: {bar_path}")
