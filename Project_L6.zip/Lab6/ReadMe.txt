Leonte Robert
Ionescu Rares
Petre George