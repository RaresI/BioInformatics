# Desing an app that uses the sliding window method
# in order to read the tm over the seq S.
# Use a sliding window f 8 positions and choose a FASTA file for input

import math
from collections import Counter


def read_fasta_sequence(path):
    parts = []
    with open(path, "r") as handle:
        for raw in handle:
            if raw.startswith(">"):
                continue
            parts.append(raw.strip().upper())
    return "".join(parts)


def tm_simple_from_counts(counts):
    return 4 * (counts["G"] + counts["C"]) + 2 * (counts["A"] + counts["T"])


def tm_advanced_from_counts(counts, win_len, na_conc=0.0001):
    gc_pct = ((counts["G"] + counts["C"]) / win_len) * 100
    return 81.5 + 16.6 * math.log10(na_conc) + 0.41 * gc_pct - (600 / win_len)


path = input("Enter the full path of your FASTA file: ").strip()
if not path:
    print("No file provided. Exiting.")
    exit()

sequence = read_fasta_sequence(path)
window_size = 8

print(f"{'Window':>6} {'Seq':>10} {'GC%':>6} {'Tm1':>6} {'Tm2':>6}")
print("-" * 40)

for start in range(0, len(sequence) - window_size + 1):
    window = sequence[start:start + window_size]
    counts = Counter(window)

    tm1 = tm_simple_from_counts(counts)
    tm2 = tm_advanced_from_counts(counts, window_size)
    gc_pct = ((counts["G"] + counts["C"]) / window_size) * 100

    end = start + window_size
    print(f"{start+1}-{end:<3} {window:>10} {gc_pct:6.2f} {tm1:6.2f} {tm2:6.2f}")
