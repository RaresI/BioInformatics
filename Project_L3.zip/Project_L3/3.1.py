# The melting temp (tm) is the temp at which one half of a particular DNA will disociate
# and become a single stand of DNA primerland and seq are of critical importance
# in designing the parameters of a successful amplification, the tm of a nucleic acid duplex
# increseas both with its lenght and with increasing GC content

# tm = 4 ( G + C ) + 2 (A + T)
# tm = 81.5 + 16.6(log10([Nat])) + 0.41*(%GC) - 600/lenght

# Implement an app that computes the tm of a DNA seq by using one of those formulas or both of them

# Input = a string of DNA
# Output = temp in Celsius

import math
from collections import Counter


def tm_simple_from_counts(counts):
    return 4 * (counts["G"] + counts["C"]) + 2 * (counts["A"] + counts["T"])


def tm_advanced_from_counts(counts, n_total, na_conc=0.0001):
    gc_pct = ((counts["G"] + counts["C"]) / n_total) * 100
    return 81.5 + 16.6 * math.log10(na_conc) + 0.41 * gc_pct - (600 / n_total)


seq = input("Enter DNA sequence: ").upper()
counts = Counter(seq)
n = len(seq)

tm1 = tm_simple_from_counts(counts)
tm2 = tm_advanced_from_counts(counts, n)

print(f"Tm (1st formula): {tm1:.2f} °C")
print(f"Tm (2nd formula): {tm2:.2f} °C")
