import numpy as np
import math
from typing import List, Tuple


def create_count_matrix(sequences: List[str]) -> dict:
    if not sequences:
        return {}
    
    length = len(sequences[0])
    nucleotides = ['A', 'C', 'G', 'T']
    
    count_matrix = {nuc: [0] * length for nuc in nucleotides}
    
    for seq in sequences:
        for pos, base in enumerate(seq):
            if base in count_matrix:
                count_matrix[base][pos] += 1
    
    return count_matrix


def create_weight_matrix(count_matrix: dict, num_sequences: int) -> dict:
    weight_matrix = {}
    for nuc in count_matrix:
        weight_matrix[nuc] = [count / num_sequences for count in count_matrix[nuc]]
    
    return weight_matrix


def create_relative_frequencies_matrix(weight_matrix: dict) -> dict:
    return weight_matrix.copy()


def create_log_likelihood_matrix(weight_matrix: dict, null_model: float = 0.25) -> dict:
    log_likelihood_matrix = {}
    
    for nuc in weight_matrix:
        log_likelihood_matrix[nuc] = []
        for freq in weight_matrix[nuc]:
            if freq > 0:
                log_likelihood = math.log(freq / null_model)
            else:
                log_likelihood = math.log(0.01 / null_model)
            log_likelihood_matrix[nuc].append(log_likelihood)
    
    return log_likelihood_matrix


def calculate_window_score(window: str, log_likelihood_matrix: dict) -> float:
    score = 0.0
    for pos, base in enumerate(window):
        if base in log_likelihood_matrix and pos < len(log_likelihood_matrix[base]):
            score += log_likelihood_matrix[base][pos]
    
    return score


def analyze_sequence(sequence: str, log_likelihood_matrix: dict, motif_length: int) -> List[Tuple[int, str, float]]:
    results = []
    
    for i in range(len(sequence) - motif_length + 1):
        window = sequence[i:i + motif_length]
        score = calculate_window_score(window, log_likelihood_matrix)
        results.append((i, window, score))
    
    return results


def print_matrix(matrix: dict, title: str, precision: int = 2):
    print(f"\n{title}")
    print("=" * 60)
    
    positions = len(list(matrix.values())[0])
    
    print(f"{'':>4}", end="")
    for pos in range(1, positions + 1):
        print(f"{pos:>8}", end="")
    print()
    print("-" * (4 + 8 * positions))
    
    for nuc in ['A', 'C', 'G', 'T']:
        print(f"{nuc:>4}", end="")
        for value in matrix[nuc]:
            if isinstance(value, int):
                print(f"{value:>8}", end="")
            else:
                print(f"{value:>8.{precision}f}", end="")
        print()


def main():
    motif_sequences = [
        "GAGGTAAAC",
        "TCCGTAAGT",
        "CAGGTTGGA",
        "ACAGTCAGT",
        "TAGGTCATT",
        "TAGGTACTG",
        "ATGGTAACT",
        "CAGGTATAC",
        "TGTGTGAGT",
        "AAGGTAAGT"
    ]
    
    print("DNA MOTIF FINDING FOR SPLICE SITE RECOGNITION")
    print("=" * 60)
    print("\nKnown motif sequences (exon-intron boundary):")
    for i, seq in enumerate(motif_sequences, 1):
        print(f"{i:2d}. {seq}")
    
    count_matrix = create_count_matrix(motif_sequences)
    print_matrix(count_matrix, "STEP 1: COUNT MATRIX", precision=0)
    
    weight_matrix = create_weight_matrix(count_matrix, len(motif_sequences))
    print_matrix(weight_matrix, "STEP 2: WEIGHT MATRIX (Frequencies)", precision=2)
    
    rel_freq_matrix = create_relative_frequencies_matrix(weight_matrix)
    print_matrix(rel_freq_matrix, "STEP 3: RELATIVE FREQUENCIES MATRIX", precision=2)
    
    log_likelihood_matrix = create_log_likelihood_matrix(weight_matrix)
    print_matrix(log_likelihood_matrix, "STEP 4: LOG-LIKELIHOODS MATRIX", precision=3)
    
    sequence_S = "CAGGTTGGAAACGTAATCAGCGATTACGCATGACGTAA"
    motif_length = len(motif_sequences[0])
    
    print(f"\n\nSTEP 5: SEQUENCE ANALYSIS")
    print("=" * 60)
    print(f"Target sequence: {sequence_S}")
    print(f"Motif length: {motif_length}")
    print(f"\nSliding window scores:")
    print("-" * 60)
    
    results = analyze_sequence(sequence_S, log_likelihood_matrix, motif_length)
    
    max_score = max(results, key=lambda x: x[2])
    
    print(f"{'Position':>8} {'Window':>12} {'Score':>10}")
    print("-" * 60)
    
    for pos, window, score in results:
        marker = " <-- MAX" if (pos, window, score) == max_score else ""
        print(f"{pos:>8} {window:>12} {score:>10.3f}{marker}")
    
    print("\n" + "=" * 60)
    print("ANALYSIS RESULTS")
    print("=" * 60)
    
    scores = [score for _, _, score in results]
    mean_score = np.mean(scores)
    std_score = np.std(scores)
    threshold = mean_score + std_score
    
    print(f"\nScore statistics:")
    print(f"  Mean score: {mean_score:.3f}")
    print(f"  Std deviation: {std_score:.3f}")
    print(f"  Threshold (mean + 1 std): {threshold:.3f}")
    print(f"\nMaximum score found:")
    print(f"  Position: {max_score[0]}")
    print(f"  Window: {max_score[1]}")
    print(f"  Score: {max_score[2]:.3f}")
    
    significant_hits = [(pos, window, score) for pos, window, score in results if score > threshold]
    
    print(f"\n{'*' * 60}")
    if significant_hits:
        print("✓ YES - EXON-INTRON BORDER SIGNALS DETECTED!")
        print(f"{'*' * 60}")
        print(f"\nFound {len(significant_hits)} significant hit(s) above threshold:")
        for pos, window, score in significant_hits:
            print(f"  Position {pos}: {window} (score: {score:.3f})")
        
        print("\nInterpretation:")
        print(f"  The sequence contains region(s) that match the exon-intron")
        print(f"  boundary motif pattern. The highest scoring window '{max_score[1]}'")
        print(f"  at position {max_score[0]} shows strong similarity to known")
        print(f"  splice site sequences.")
    else:
        print("✗ NO - No strong exon-intron border signals detected")
        print(f"{'*' * 60}")
        print(f"\nThe highest scoring window '{max_score[1]}' at position {max_score[0]}")
        print(f"has a score of {max_score[2]:.3f}, which is below the significance")
        print(f"threshold of {threshold:.3f}.")


if __name__ == "__main__":
    main()
