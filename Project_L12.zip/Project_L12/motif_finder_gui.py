import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox
import numpy as np
import math
from typing import List, Tuple


def create_count_matrix(sequences: List[str]) -> dict:
    if not sequences:
        return {}
    
    length = len(sequences[0])
    nucleotides = ['A', 'C', 'G', 'T']
    
    count_matrix = {nuc: [0] * length for nuc in nucleotides}
    
    for seq in sequences:
        for pos, base in enumerate(seq):
            if base in count_matrix:
                count_matrix[base][pos] += 1
    
    return count_matrix


def create_weight_matrix(count_matrix: dict, num_sequences: int) -> dict:
    weight_matrix = {}
    for nuc in count_matrix:
        weight_matrix[nuc] = [count / num_sequences for count in count_matrix[nuc]]
    
    return weight_matrix


def create_relative_frequencies_matrix(weight_matrix: dict) -> dict:
    return weight_matrix.copy()


def create_log_likelihood_matrix(weight_matrix: dict, null_model: float = 0.25) -> dict:
    log_likelihood_matrix = {}
    
    for nuc in weight_matrix:
        log_likelihood_matrix[nuc] = []
        for freq in weight_matrix[nuc]:
            if freq > 0:
                log_likelihood = math.log(freq / null_model)
            else:
                log_likelihood = math.log(0.01 / null_model)
            log_likelihood_matrix[nuc].append(log_likelihood)
    
    return log_likelihood_matrix


def calculate_window_score(window: str, log_likelihood_matrix: dict) -> float:
    score = 0.0
    for pos, base in enumerate(window):
        if base in log_likelihood_matrix and pos < len(log_likelihood_matrix[base]):
            score += log_likelihood_matrix[base][pos]
    
    return score


def analyze_sequence(sequence: str, log_likelihood_matrix: dict, motif_length: int) -> List[Tuple[int, str, float]]:
    results = []
    
    for i in range(len(sequence) - motif_length + 1):
        window = sequence[i:i + motif_length]
        score = calculate_window_score(window, log_likelihood_matrix)
        results.append((i, window, score))
    
    return results


def format_matrix(matrix: dict, title: str, precision: int = 2) -> str:
    output = f"\n{title}\n"
    output += "=" * 60 + "\n"
    
    positions = len(list(matrix.values())[0])
    
    output += f"{'':>4}"
    for pos in range(1, positions + 1):
        output += f"{pos:>8}"
    output += "\n"
    output += "-" * (4 + 8 * positions) + "\n"
    
    for nuc in ['A', 'C', 'G', 'T']:
        output += f"{nuc:>4}"
        for value in matrix[nuc]:
            if isinstance(value, int):
                output += f"{value:>8}"
            else:
                output += f"{value:>8.{precision}f}"
        output += "\n"
    
    return output


class MotifFinderGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("DNA Motif Finder - Splice Site Recognition")
        self.root.geometry("1000x800")
        
        self.motif_sequences = [
            "GAGGTAAAC",
            "TCCGTAAGT",
            "CAGGTTGGA",
            "ACAGTCAGT",
            "TAGGTCATT",
            "TAGGTACTG",
            "ATGGTAACT",
            "CAGGTATAC",
            "TGTGTGAGT",
            "AAGGTAAGT"
        ]
        
        self.setup_ui()
        
    def setup_ui(self):
        main_frame = ttk.Frame(self.root, padding="10")
        main_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        self.root.columnconfigure(0, weight=1)
        self.root.rowconfigure(0, weight=1)
        main_frame.columnconfigure(0, weight=1)
        main_frame.rowconfigure(3, weight=1)
        
        title_label = ttk.Label(main_frame, text="DNA MOTIF FINDING FOR SPLICE SITE RECOGNITION", 
                                font=('Arial', 14, 'bold'))
        title_label.grid(row=0, column=0, pady=10)
        
        motif_frame = ttk.LabelFrame(main_frame, text="Known Motif Sequences (Exon-Intron Boundary)", padding="10")
        motif_frame.grid(row=1, column=0, sticky=(tk.W, tk.E), pady=5)
        
        motif_text = "  ".join([f"{i+1}. {seq}" for i, seq in enumerate(self.motif_sequences)])
        motif_label = ttk.Label(motif_frame, text=motif_text, font=('Courier', 9))
        motif_label.grid(row=0, column=0)
        
        input_frame = ttk.LabelFrame(main_frame, text="Sequence Analysis", padding="10")
        input_frame.grid(row=2, column=0, sticky=(tk.W, tk.E), pady=5)
        
        ttk.Label(input_frame, text="Target Sequence:").grid(row=0, column=0, sticky=tk.W, pady=5)
        
        self.sequence_entry = ttk.Entry(input_frame, width=50, font=('Courier', 10))
        self.sequence_entry.grid(row=0, column=1, padx=5, pady=5)
        self.sequence_entry.insert(0, "CAGGTTGGAAACGTAATCAGCGATTACGCATGACGTAA")
        
        analyze_btn = ttk.Button(input_frame, text="Analyze Sequence", command=self.analyze)
        analyze_btn.grid(row=0, column=2, padx=5, pady=5)
        
        clear_btn = ttk.Button(input_frame, text="Clear Results", command=self.clear_results)
        clear_btn.grid(row=0, column=3, padx=5, pady=5)
        
        notebook = ttk.Notebook(main_frame)
        notebook.grid(row=3, column=0, sticky=(tk.W, tk.E, tk.N, tk.S), pady=5)
        
        self.matrices_text = scrolledtext.ScrolledText(notebook, wrap=tk.NONE, font=('Courier', 9))
        notebook.add(self.matrices_text, text="Matrices")
        
        self.results_text = scrolledtext.ScrolledText(notebook, wrap=tk.WORD, font=('Courier', 9))
        notebook.add(self.results_text, text="Analysis Results")
        
        status_frame = ttk.Frame(main_frame)
        status_frame.grid(row=4, column=0, sticky=(tk.W, tk.E), pady=5)
        
        self.status_label = ttk.Label(status_frame, text="Ready", relief=tk.SUNKEN, anchor=tk.W)
        self.status_label.pack(fill=tk.X)
        
    def analyze(self):
        sequence = self.sequence_entry.get().strip().upper()
        
        if not sequence:
            messagebox.showerror("Error", "Please enter a sequence to analyze!")
            return
        
        if not all(c in 'ACGT' for c in sequence):
            messagebox.showerror("Error", "Sequence must contain only A, C, G, T nucleotides!")
            return
        
        self.status_label.config(text="Analyzing...")
        self.root.update()
        
        try:
            count_matrix = create_count_matrix(self.motif_sequences)
            weight_matrix = create_weight_matrix(count_matrix, len(self.motif_sequences))
            rel_freq_matrix = create_relative_frequencies_matrix(weight_matrix)
            log_likelihood_matrix = create_log_likelihood_matrix(weight_matrix)
            
            self.matrices_text.delete(1.0, tk.END)
            self.matrices_text.insert(tk.END, format_matrix(count_matrix, "STEP 1: COUNT MATRIX", precision=0))
            self.matrices_text.insert(tk.END, "\n" + format_matrix(weight_matrix, "STEP 2: WEIGHT MATRIX (Frequencies)", precision=2))
            self.matrices_text.insert(tk.END, "\n" + format_matrix(rel_freq_matrix, "STEP 3: RELATIVE FREQUENCIES MATRIX", precision=2))
            self.matrices_text.insert(tk.END, "\n" + format_matrix(log_likelihood_matrix, "STEP 4: LOG-LIKELIHOODS MATRIX", precision=3))
            
            motif_length = len(self.motif_sequences[0])
            results = analyze_sequence(sequence, log_likelihood_matrix, motif_length)
            
            self.results_text.delete(1.0, tk.END)
            
            self.results_text.insert(tk.END, f"STEP 5: SEQUENCE ANALYSIS\n")
            self.results_text.insert(tk.END, "=" * 60 + "\n")
            self.results_text.insert(tk.END, f"Target sequence: {sequence}\n")
            self.results_text.insert(tk.END, f"Motif length: {motif_length}\n\n")
            self.results_text.insert(tk.END, "Sliding window scores:\n")
            self.results_text.insert(tk.END, "-" * 60 + "\n")
            
            max_score = max(results, key=lambda x: x[2])
            
            self.results_text.insert(tk.END, f"{'Position':>8} {'Window':>12} {'Score':>10}\n")
            self.results_text.insert(tk.END, "-" * 60 + "\n")
            
            for pos, window, score in results:
                marker = " <-- MAX" if (pos, window, score) == max_score else ""
                self.results_text.insert(tk.END, f"{pos:>8} {window:>12} {score:>10.3f}{marker}\n")
            
            self.results_text.insert(tk.END, "\n" + "=" * 60 + "\n")
            self.results_text.insert(tk.END, "ANALYSIS RESULTS\n")
            self.results_text.insert(tk.END, "=" * 60 + "\n")
            
            scores = [score for _, _, score in results]
            mean_score = np.mean(scores)
            std_score = np.std(scores)
            threshold = mean_score + std_score
            
            self.results_text.insert(tk.END, f"\nScore statistics:\n")
            self.results_text.insert(tk.END, f"  Mean score: {mean_score:.3f}\n")
            self.results_text.insert(tk.END, f"  Std deviation: {std_score:.3f}\n")
            self.results_text.insert(tk.END, f"  Threshold (mean + 1 std): {threshold:.3f}\n")
            self.results_text.insert(tk.END, f"\nMaximum score found:\n")
            self.results_text.insert(tk.END, f"  Position: {max_score[0]}\n")
            self.results_text.insert(tk.END, f"  Window: {max_score[1]}\n")
            self.results_text.insert(tk.END, f"  Score: {max_score[2]:.3f}\n")
            
            significant_hits = [(pos, window, score) for pos, window, score in results if score > threshold]
            
            self.results_text.insert(tk.END, "\n" + "*" * 60 + "\n")
            if significant_hits:
                self.results_text.insert(tk.END, "✓ YES - EXON-INTRON BORDER SIGNALS DETECTED!\n")
                self.results_text.insert(tk.END, "*" * 60 + "\n")
                self.results_text.insert(tk.END, f"\nFound {len(significant_hits)} significant hit(s) above threshold:\n")
                for pos, window, score in significant_hits:
                    self.results_text.insert(tk.END, f"  Position {pos}: {window} (score: {score:.3f})\n")
                
                self.results_text.insert(tk.END, "\nInterpretation:\n")
                self.results_text.insert(tk.END, f"  The sequence contains region(s) that match the exon-intron\n")
                self.results_text.insert(tk.END, f"  boundary motif pattern. The highest scoring window '{max_score[1]}'\n")
                self.results_text.insert(tk.END, f"  at position {max_score[0]} shows strong similarity to known\n")
                self.results_text.insert(tk.END, f"  splice site sequences.\n")
                
                self.status_label.config(text=f"Analysis complete - Signals DETECTED! ({len(significant_hits)} hit(s))")
            else:
                self.results_text.insert(tk.END, "✗ NO - No strong exon-intron border signals detected\n")
                self.results_text.insert(tk.END, "*" * 60 + "\n")
                self.results_text.insert(tk.END, f"\nThe highest scoring window '{max_score[1]}' at position {max_score[0]}\n")
                self.results_text.insert(tk.END, f"has a score of {max_score[2]:.3f}, which is below the significance\n")
                self.results_text.insert(tk.END, f"threshold of {threshold:.3f}.\n")
                
                self.status_label.config(text="Analysis complete - No significant signals detected")
            
        except Exception as e:
            messagebox.showerror("Error", f"An error occurred during analysis:\n{str(e)}")
            self.status_label.config(text="Error during analysis")
    
    def clear_results(self):
        self.matrices_text.delete(1.0, tk.END)
        self.results_text.delete(1.0, tk.END)
        self.status_label.config(text="Results cleared - Ready")


def main():
    root = tk.Tk()
    app = MotifFinderGUI(root)
    root.mainloop()


if __name__ == "__main__":
    main()
