Petre George-Alexandru 1241B
Ionescu Rares-Andrei 1241B
Leonte Robert 1241B