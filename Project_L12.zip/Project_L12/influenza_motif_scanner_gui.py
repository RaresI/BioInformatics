import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox, filedialog
import numpy as np
import math
from typing import List, Tuple, Dict
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure
import os
import glob
import re


def create_count_matrix(sequences: List[str]) -> dict:
    if not sequences:
        return {}
    
    length = len(sequences[0])
    nucleotides = ['A', 'C', 'G', 'T']
    
    count_matrix = {nuc: [0] * length for nuc in nucleotides}
    
    for seq in sequences:
        for pos, base in enumerate(seq):
            if base in count_matrix:
                count_matrix[base][pos] += 1
    
    return count_matrix


def create_weight_matrix(count_matrix: dict, num_sequences: int) -> dict:
    weight_matrix = {}
    for nuc in count_matrix:
        weight_matrix[nuc] = [count / num_sequences for count in count_matrix[nuc]]
    
    return weight_matrix


def create_log_likelihood_matrix(weight_matrix: dict, null_model: float = 0.25) -> dict:
    log_likelihood_matrix = {}
    
    for nuc in weight_matrix:
        log_likelihood_matrix[nuc] = []
        for freq in weight_matrix[nuc]:
            if freq > 0:
                log_likelihood = math.log(freq / null_model)
            else:
                log_likelihood = math.log(0.01 / null_model)
            log_likelihood_matrix[nuc].append(log_likelihood)
    
    return log_likelihood_matrix


def calculate_window_score(window: str, log_likelihood_matrix: dict) -> float:
    score = 0.0
    for pos, base in enumerate(window):
        if base in log_likelihood_matrix and pos < len(log_likelihood_matrix[base]):
            score += log_likelihood_matrix[base][pos]
    
    return score


def scan_genome(sequence: str, log_likelihood_matrix: dict, motif_length: int) -> List[Tuple[int, str, float]]:
    results = []
    
    for i in range(len(sequence) - motif_length + 1):
        window = sequence[i:i + motif_length]
        if all(base in 'ACGT' for base in window):
            score = calculate_window_score(window, log_likelihood_matrix)
            results.append((i, window, score))
    
    return results


def find_significant_motifs(results: List[Tuple[int, str, float]], threshold: float) -> List[Tuple[int, str, float]]:
    return [(pos, window, score) for pos, window, score in results if score > threshold]


def read_fasta(path: str) -> str:
    seq_lines = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith(">"):
                continue
            seq_lines.append(line)
    return "".join(seq_lines).upper()


def natural_key(filename: str):
    m = re.search(r"\((\d+)\)", filename)
    return int(m.group(1)) if m else filename


class InfluenzaMotifScannerGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Influenza Genome Motif Scanner")
        self.root.geometry("1400x900")
        
        self.motif_sequences = [
            "GAGGTAAAC",
            "TCCGTAAGT",
            "CAGGTTGGA",
            "ACAGTCAGT",
            "TAGGTCATT",
            "TAGGTACTG",
            "ATGGTAACT",
            "CAGGTATAC",
            "TGTGTGAGT",
            "AAGGTAAGT"
        ]
        
        self.genomes = self.prepare_genomes()
        self.log_likelihood_matrix = None
        self.motif_length = len(self.motif_sequences[0])
        self.current_canvas = None
        
        self.setup_ui()
        self.build_motif_model()
        
    def prepare_genomes(self):
        script_dir = os.path.dirname(os.path.abspath(__file__))
        
        fasta_files = sorted(
            glob.glob(os.path.join(script_dir, "sequence (*.fasta")) +
            glob.glob(os.path.join(script_dir, "sequence (*.fa")),
            key=natural_key
        )
        
        if not fasta_files:
            fasta_files = [
                os.path.join(script_dir, f"sequence ({i}).fasta") 
                for i in range(1, 11) 
                if os.path.exists(os.path.join(script_dir, f"sequence ({i}).fasta"))
            ]
        
        if not fasta_files:
            messagebox.showwarning(
                "No FASTA Files Found",
                "No FASTA files found. Using demo sequences.\n\n"
                "To use real influenza genomes, place files named:\n"
                "sequence (1).fasta, sequence (2).fasta, etc.\n"
                "in the same directory as this script."
            )
            return self.prepare_demo_genomes()
        
        genomes = []
        for idx, fasta_path in enumerate(fasta_files, 1):
            try:
                sequence = read_fasta(fasta_path)
                filename = os.path.basename(fasta_path)
                
                genome_info = {
                    'id': f"genome_{idx}",
                    'accession': os.path.splitext(filename)[0],
                    'description': f"Influenza genome from {filename}",
                    'sequence': sequence,
                    'length': len(sequence),
                    'file': fasta_path
                }
                genomes.append(genome_info)
            except Exception as e:
                print(f"Error reading {fasta_path}: {e}")
        
        if not genomes:
            return self.prepare_demo_genomes()
        
        return genomes
    
    def prepare_demo_genomes(self):
        test_sequences = [
            "CAGGTTGGAAACGTAATCAGCGATTACGCATGACGTAA",
            "GAGGTAAACTCCGTAAGTCAGGTTGGAACAGTCAGTTAGGTCATT",
            "TAGGTACTGATGGTAACTCAGGTATACTGTGTGAGTAGGGTAAGT",
            "GCATGAGGTAAACTTCGACAGGTTGGACGTACAGTCAGTGCTA",
            "ATAGGTCATTGCGATGGTAACTCGTAGGTATACTGTGTGAGT",
            "CTGAGGTAAACGTAGGTACTGCAGGTTGGAACAGTCAGT",
            "GCAGGTATACATGGTAACTTGTGTGAGTAGGGTAAGTCG",
            "TGAGGTAAACTCCGTAAGTTAGGTCATTCAGGTTGGAAC",
            "ACAGTCAGTGCTAGGTACTGATGGTAACTCAGGTATAC",
            "TGTGTGAGTAGGGTAAGTGCATGAGGTAAACTCCGTAAGT"
        ]
        
        genomes = []
        for idx, sequence in enumerate(test_sequences, 1):
            genome_info = {
                'id': f"genome_{idx}",
                'accession': f"DEMO_{idx:02d}",
                'description': f"Demo sequence {idx}",
                'sequence': sequence.upper(),
                'length': len(sequence),
                'file': None
            }
            genomes.append(genome_info)
        return genomes
    
    def build_motif_model(self):
        count_matrix = create_count_matrix(self.motif_sequences)
        weight_matrix = create_weight_matrix(count_matrix, len(self.motif_sequences))
        self.log_likelihood_matrix = create_log_likelihood_matrix(weight_matrix)
        
    def setup_ui(self):
        main_frame = ttk.Frame(self.root, padding="10")
        main_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        self.root.columnconfigure(0, weight=1)
        self.root.rowconfigure(0, weight=1)
        main_frame.columnconfigure(1, weight=1)
        main_frame.rowconfigure(1, weight=1)
        
        title_label = ttk.Label(main_frame, text="INFLUENZA GENOME MOTIF SCANNER", 
                                font=('Arial', 16, 'bold'))
        title_label.grid(row=0, column=0, columnspan=2, pady=10)
        
        left_frame = ttk.Frame(main_frame, padding="5")
        left_frame.grid(row=1, column=0, sticky=(tk.W, tk.E, tk.N, tk.S), padx=(0, 5))
        
        genomes_frame = ttk.LabelFrame(left_frame, text="Influenza Genomes", padding="10")
        genomes_frame.pack(fill=tk.BOTH, expand=True)
        
        list_frame = ttk.Frame(genomes_frame)
        list_frame.pack(fill=tk.BOTH, expand=True)
        
        scrollbar = ttk.Scrollbar(list_frame)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        self.genome_listbox = tk.Listbox(list_frame, yscrollcommand=scrollbar.set,
                                         font=('Courier', 10), height=15, width=30)
        self.genome_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.config(command=self.genome_listbox.yview)
        
        for genome in self.genomes:
            display_text = f"{genome['accession']} ({genome['length']} bp)"
            if genome.get('file'):
                display_text += f" [{os.path.basename(genome['file'])}]"
            self.genome_listbox.insert(tk.END, display_text)
        
        self.genome_listbox.bind('<<ListBoxSelect>>', self.on_genome_select)
        
        button_frame = ttk.Frame(genomes_frame)
        button_frame.pack(fill=tk.X, pady=(10, 0))
        
        scan_btn = ttk.Button(button_frame, text="Scan Selected Genome", command=self.scan_selected)
        scan_btn.pack(side=tk.LEFT, padx=5)
        
        scan_all_btn = ttk.Button(button_frame, text="Scan All Genomes", command=self.scan_all)
        scan_all_btn.pack(side=tk.LEFT, padx=5)
        
        right_frame = ttk.Frame(main_frame, padding="5")
        right_frame.grid(row=1, column=1, sticky=(tk.W, tk.E, tk.N, tk.S))
        right_frame.columnconfigure(0, weight=1)
        right_frame.rowconfigure(0, weight=3)
        right_frame.rowconfigure(1, weight=1)
        
        chart_frame = ttk.LabelFrame(right_frame, text="Motif Scan Visualization", padding="5")
        chart_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S), pady=(0, 5))
        chart_frame.columnconfigure(0, weight=1)
        chart_frame.rowconfigure(0, weight=1)
        
        self.chart_container = ttk.Frame(chart_frame)
        self.chart_container.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        self.chart_container.columnconfigure(0, weight=1)
        self.chart_container.rowconfigure(0, weight=1)
        
        placeholder_label = ttk.Label(self.chart_container, text="Select a genome to scan",
                                     font=('Arial', 12), foreground='gray')
        placeholder_label.grid(row=0, column=0)
        
        results_frame = ttk.LabelFrame(right_frame, text="Analysis Results", padding="5")
        results_frame.grid(row=1, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        self.results_text = scrolledtext.ScrolledText(results_frame, wrap=tk.WORD, 
                                                      font=('Courier', 9), height=10)
        self.results_text.pack(fill=tk.BOTH, expand=True)
        
        status_frame = ttk.Frame(main_frame)
        status_frame.grid(row=2, column=0, columnspan=2, sticky=(tk.W, tk.E), pady=(5, 0))
        
        self.status_label = ttk.Label(status_frame, text="Ready - Select a genome to scan", 
                                      relief=tk.SUNKEN, anchor=tk.W)
        self.status_label.pack(fill=tk.X)
        
    def on_genome_select(self, event):
        selection = self.genome_listbox.curselection()
        if selection:
            idx = selection[0]
            genome = self.genomes[idx]
            self.status_label.config(text=f"Selected: {genome['accession']} - {genome['sequence']}")
    
    def scan_selected(self):
        selection = self.genome_listbox.curselection()
        if not selection:
            messagebox.showwarning("No Selection", "Please select a genome to scan!")
            return
        
        idx = selection[0]
        genome = self.genomes[idx]
        self.scan_genome(genome)
    
    def scan_all(self):
        if messagebox.askyesno("Scan All", "Scan all 10 genomes? This may take a moment."):
            for idx, genome in enumerate(self.genomes):
                self.genome_listbox.selection_clear(0, tk.END)
                self.genome_listbox.selection_set(idx)
                self.genome_listbox.see(idx)
                self.scan_genome(genome)
                self.root.update()
            
            messagebox.showinfo("Complete", "All genomes scanned successfully!")
    
    def scan_genome(self, genome):
        self.status_label.config(text=f"Scanning {genome['accession']}...")
        self.root.update()
        
        try:
            scan_results = scan_genome(genome['sequence'], self.log_likelihood_matrix, self.motif_length)
            
            if not scan_results:
                messagebox.showerror("Error", "No valid windows found in genome.")
                return
            
            scores = [score for _, _, score in scan_results]
            mean_score = np.mean(scores)
            std_score = np.std(scores)
            threshold = mean_score + std_score
            
            significant_hits = sorted(
                find_significant_motifs(scan_results, threshold),
                key=lambda x: x[2],
                reverse=True
            )
            
            self.display_results(genome, scan_results, significant_hits, threshold, mean_score, std_score)
            self.plot_scan_results(genome, scan_results, significant_hits, threshold)
            
            self.status_label.config(text=f"Scan complete: {genome['accession']} - Found {len(significant_hits)} significant motifs")
            
        except Exception as e:
            messagebox.showerror("Error", f"Error during scanning:\n{str(e)}")
            self.status_label.config(text="Error during scan")
    
    def display_results(self, genome, scan_results, significant_hits, threshold, mean_score, std_score):
        self.results_text.delete(1.0, tk.END)
        
        self.results_text.insert(tk.END, f"GENOME: {genome['accession']}\n")
        seq_preview = genome['sequence'][:60] + "..." if len(genome['sequence']) > 60 else genome['sequence']
        self.results_text.insert(tk.END, f"Sequence: {seq_preview}\n")
        self.results_text.insert(tk.END, f"Length: {genome['length']} bp\n")
        self.results_text.insert(tk.END, "=" * 70 + "\n\n")
        
        self.results_text.insert(tk.END, f"Statistics:\n")
        self.results_text.insert(tk.END, f"  Windows scanned: {len(scan_results)}\n")
        self.results_text.insert(tk.END, f"  Mean score: {mean_score:.3f}\n")
        self.results_text.insert(tk.END, f"  Std deviation: {std_score:.3f}\n")
        self.results_text.insert(tk.END, f"  Threshold: {threshold:.3f}\n\n")
        
        if significant_hits:
            self.results_text.insert(tk.END, f"✓ SIGNIFICANT MOTIFS DETECTED: {len(significant_hits)}\n")
            self.results_text.insert(tk.END, "-" * 70 + "\n")
            
            for idx, (pos, window, score) in enumerate(significant_hits[:10], 1):
                self.results_text.insert(tk.END, f"{idx:2d}. Position {pos}: {window} (score: {score:.3f})\n")
            
            if len(significant_hits) > 10:
                self.results_text.insert(tk.END, f"\n... and {len(significant_hits) - 10} more\n")
            
            self.results_text.insert(tk.END, "\n" + "=" * 70 + "\n")
            self.results_text.insert(tk.END, "Interpretation:\n")
            self.results_text.insert(tk.END, f"The genome contains {len(significant_hits)} region(s) that match\n")
            self.results_text.insert(tk.END, f"the motif pattern with high confidence. The top hit is at\n")
            self.results_text.insert(tk.END, f"position {significant_hits[0][0]} with sequence '{significant_hits[0][1]}'.\n")
        else:
            self.results_text.insert(tk.END, "✗ NO SIGNIFICANT MOTIFS DETECTED\n")
            self.results_text.insert(tk.END, "-" * 70 + "\n")
            self.results_text.insert(tk.END, f"No windows exceeded the threshold of {threshold:.3f}\n")
    
    def plot_scan_results(self, genome, scan_results, significant_hits, threshold):
        for widget in self.chart_container.winfo_children():
            widget.destroy()
        
        if self.current_canvas:
            self.current_canvas.get_tk_widget().destroy()
        
        fig = Figure(figsize=(10, 7), dpi=80)
        
        ax1 = fig.add_subplot(211)
        ax2 = fig.add_subplot(212)
        
        positions = [pos for pos, _, _ in scan_results]
        scores = [score for _, _, score in scan_results]
        
        step = max(1, len(positions) // 1000)
        positions_plot = positions[::step]
        scores_plot = scores[::step]
        
        ax1.plot(positions_plot, scores_plot, 'b-', linewidth=1, alpha=0.7, label='Score')
        ax1.axhline(y=threshold, color='r', linestyle='--', linewidth=2, 
                   label=f'Threshold ({threshold:.2f})')
        
        if significant_hits:
            sig_positions = [pos for pos, _, _ in significant_hits]
            sig_scores = [score for _, _, score in significant_hits]
            ax1.scatter(sig_positions, sig_scores, color='red', s=50, zorder=5, 
                       label=f'Significant ({len(significant_hits)})', alpha=0.8)
        
        ax1.set_xlabel('Genome Position', fontsize=10)
        ax1.set_ylabel('Log-likelihood Score', fontsize=10)
        
        title_text = f'{genome["accession"]} ({genome["length"]} bp)'
        ax1.set_title(title_text, fontsize=10, fontweight='bold')
        ax1.legend(loc='upper right', fontsize=8)
        ax1.grid(True, alpha=0.3)
        
        if significant_hits:
            top_hits = significant_hits[:10]
            
            hit_scores = [score for _, _, score in top_hits]
            hit_labels = [f"Pos {pos}: {window}" for pos, window, _ in top_hits]
            
            y_positions = range(len(top_hits))
            bars = ax2.barh(y_positions, hit_scores, color='steelblue', alpha=0.7)
            ax2.set_yticks(y_positions)
            ax2.set_yticklabels(hit_labels, fontsize=7)
            ax2.set_xlabel('Score', fontsize=10)
            ax2.set_title(f'Top {len(top_hits)} Significant Motifs', fontsize=10, fontweight='bold')
            ax2.grid(True, alpha=0.3, axis='x')
            
            for i, (bar, score) in enumerate(zip(bars, hit_scores)):
                ax2.text(score + 0.05, i, f'{score:.2f}', va='center', fontsize=7)
        else:
            ax2.text(0.5, 0.5, 'No significant motifs found', 
                    horizontalalignment='center', verticalalignment='center',
                    transform=ax2.transAxes, fontsize=12, color='gray', fontweight='bold')
            ax2.set_xlim(0, 1)
            ax2.set_ylim(0, 1)
            ax2.axis('off')
        
        fig.tight_layout()
        
        self.current_canvas = FigureCanvasTkAgg(fig, master=self.chart_container)
        self.current_canvas.draw()
        self.current_canvas.get_tk_widget().grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))


def main():
    root = tk.Tk()
    app = InfluenzaMotifScannerGUI(root)
    root.mainloop()


if __name__ == "__main__":
    main()
