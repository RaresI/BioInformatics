import os
import math
import glob
import pandas as pd
import matplotlib.pyplot as plt

# ----------------------------
# A) Motif instances (from Ex1 / your screenshot)
# ----------------------------
seqs_all = [
    "GAGGTAAAC",  # row 1
    "TCCGTAAGT",  # row 2
    "CAGGTTGGA",  # row 3
    "ACAGTCAGT",  # row 4
    "TAGGTCATT",  # row 5
    "TAGGTACTG",  # row 6
    "ATGGTAACT",  # row 7
    "CAGGTATAC",  # row 8
    "TGTGTGAGT",  # row 9
    "AAGGTAAGT",  # row 10
]

USE_FIRST_N = 9          # change to 10 if your instructor wants all 10
pseudocount = 1.0        # smoothing; set to 0.0 only if required (risk of log(0))
alphabet = ["A", "C", "G", "T"]
null = {b: 0.25 for b in alphabet}

seqs = seqs_all[:USE_FIRST_N]
if not seqs:
    raise ValueError("No motif sequences provided.")
L = len(seqs[0])
if any(len(s) != L for s in seqs):
    raise ValueError("Motif sequences must be aligned and same length.")
if any(any(ch not in alphabet for ch in s) for s in seqs):
    raise ValueError("Motif sequences must contain only A/C/G/T.")

# ----------------------------
# B) Build log-likelihood matrix
# ----------------------------
counts = {b: [0] * L for b in alphabet}
for s in seqs:
    for j, ch in enumerate(s):
        counts[ch][j] += 1

count_df = pd.DataFrame(counts, index=range(1, L + 1)).T
count_df.columns = [str(i) for i in range(1, L + 1)]

N = len(seqs)
denom = N + pseudocount * len(alphabet)
weight_df = (count_df + pseudocount) / denom

loglike_df = weight_df.copy()
for b in alphabet:
    loglike_df.loc[b] = [math.log(p / null[b]) for p in weight_df.loc[b]]

# ----------------------------
# C) FASTA reading
# ----------------------------
def read_fasta(path: str) -> str:
    """Reads the first FASTA record and returns its sequence (uppercase, no spaces)."""
    seq_lines = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            if line.startswith(">"):
                continue
            seq_lines.append(line)
    seq = "".join(seq_lines).upper()
    return seq

# ----------------------------
# D) Scoring a genome with sliding windows
# ----------------------------
def score_window(window: str, loglike: pd.DataFrame) -> float:
    score = 0.0
    for j, base in enumerate(window, start=1):
        score += float(loglike.loc[base, str(j)])
    return score

def scan_sequence(seq: str, loglike: pd.DataFrame, motif_len: int):
    """
    Returns:
      positions_1based: list of start positions (1-based)
      scores: list of float scores (same length)
      best: dict with best hit info
    Skips windows containing non-ACGT characters.
    """
    positions = []
    scores = []

    best_score = None
    best_pos = None
    best_window = None

    for i in range(len(seq) - motif_len + 1):
        w = seq[i:i + motif_len]
        if any(ch not in alphabet for ch in w):
            continue  # skip ambiguous windows (N, etc.)
        sc = score_window(w, loglike)
        pos1 = i + 1

        positions.append(pos1)
        scores.append(sc)

        if best_score is None or sc > best_score:
            best_score = sc
            best_pos = pos1
            best_window = w

    best = {"start_1based": best_pos, "window": best_window, "score": best_score}
    return positions, scores, best

# ----------------------------
# E) Plot per genome
# ----------------------------
def plot_scores(positions, scores, best, title, outpath):
    plt.figure()
    plt.plot(positions, scores)
    plt.xlabel("Window start position (1-based)")
    plt.ylabel("Log-likelihood score (sum of log-odds)")
    plt.title(title)

    # Mark best hit (vertical line + point)
    if best["start_1based"] is not None:
        plt.axvline(best["start_1based"], linestyle="--")
        plt.scatter([best["start_1based"]], [best["score"]])
        plt.text(
            best["start_1based"],
            best["score"],
            f" best @ {best['start_1based']}\n {best['window']}\n {best['score']:.3f}",
            fontsize=8,
            verticalalignment="bottom",
        )

    plt.tight_layout()
    plt.savefig(outpath, dpi=200)
    plt.close()

# ----------------------------
# F) Run on your 10 influenza genomes
# ----------------------------
def natural_key(filename: str):
    # sorts sequence (2).fasta before sequence (10).fasta
    import re
    m = re.search(r"\((\d+)\)", filename)
    return int(m.group(1)) if m else filename

fasta_files = sorted(glob.glob("sequence (.fasta") + glob.glob("sequence (.fa") +
                    glob.glob("sequence (.fna") + glob.glob("sequence (.fasta)"),
                    key=natural_key)

# The glob above can be finicky on some shells; safest:
# fasta_files = sorted(glob.glob("sequence (*.fasta"), key=natural_key)

if not fasta_files:
    # Try the exact expected names
    fasta_files = [f"sequence ({i}).fasta" for i in range(1, 11) if os.path.exists(f"sequence ({i}).fasta")]

if not fasta_files:
    raise FileNotFoundError("No FASTA files found. Put 'sequence (1).fasta' ... 'sequence (10).fasta' in this folder.")

print(f"Motif length: {L}, sequences used: {N}, pseudocount: {pseudocount}")
print(f"Found {len(fasta_files)} FASTA files.\n")

summary_rows = []
for path in fasta_files:
    seq = read_fasta(path)
    positions, scores, best = scan_sequence(seq, loglike_df, L)

    base = os.path.splitext(os.path.basename(path))[0]
    outpng = f"scan_{base.replace(' ', '_').replace('(', '').replace(')', '')}.png"
    title = f"{base} | best start={best['start_1based']} score={best['score']:.3f}" if best["score"] is not None else f"{base} | no valid windows"
    plot_scores(positions, scores, best, title, outpng)

    summary_rows.append({
        "file": path,
        "genome_length": len(seq),
        "best_start_1based": best["start_1based"],
        "best_window": best["window"],
        "best_score": best["score"],
        "plot": outpng
    })

    print(f"{path}: best_start={best['start_1based']} best_score={best['score']:.4f} -> {outpng}")

summary_df = pd.DataFrame(summary_rows)
print("\nSUMMARY")
print(summary_df.to_string(index=False))