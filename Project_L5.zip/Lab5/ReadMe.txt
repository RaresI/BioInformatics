Leonte Robert
Rares Ionescu
Petre George